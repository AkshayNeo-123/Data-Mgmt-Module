﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMgmtModule.Domain.Entities
{
   public class RecipeLog
    {
        [Key]
        public int LogId { get; set; }
        public int RecipeID { get; set; }
        public string ProductName { get; set; }
        public string Comments { get; set; }
        public int? ProjectId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? AdditiveId { get; set; }
        public int? MainPolymerId { get; set; }
        public string DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}
