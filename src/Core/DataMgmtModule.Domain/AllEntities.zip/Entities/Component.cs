﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataMgmtModule.Domain.Entities
{
    public class Component
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }
        public string Component_Name { get; set; }
        public RecipeComponent RecipeComponent { get; set; }


    }
}