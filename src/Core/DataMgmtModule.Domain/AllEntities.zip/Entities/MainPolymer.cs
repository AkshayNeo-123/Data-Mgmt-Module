﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataMgmtModule.Domain.Entities
{
    public class MainPolymer
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }
        public string PolymerName { get; set; }

        public ICollection<Recipe> Recipes { get; set; }
    }
}
