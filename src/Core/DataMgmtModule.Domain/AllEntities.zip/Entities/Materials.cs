﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataMgmtModule.Domain.Enum.MaterialsEnum;

namespace DataMgmtModule.Domain.Entities
{
    public class Materials
    {
        [Key]
        public int MaterialId { get; set; }

        public MaterialType MaterialsType { get; set; }

        public string? Designation { get; set; }

        public int? ManufacturerId { get; set; }

        public decimal Quantity { get; set; }

        public decimal Density { get; set; }

        public string? TestMethod { get; set; }

        public string? TDSFilePath { get; set; }

        public string? MSDSFilePath { get; set; }

        public StorageLocation StorageLocation { get; set; }

        public string? Description { get; set; }

        public MvrMfrType MVR_MFR { get; set; }
    }
}
