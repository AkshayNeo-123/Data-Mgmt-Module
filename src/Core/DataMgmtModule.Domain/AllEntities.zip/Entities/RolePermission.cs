﻿using System.ComponentModel.DataAnnotations;

namespace DataMgmtModule.Domain.Entities
{
    public partial class RolePermission
    {
        [Key]
        public int PermissionId { get; set; }
        public int? RoleId { get; set; }
        public string ModuleName { get; set; }
        public bool CanView { get; set; }
        public bool CanCreate { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
    }
}
