﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMgmtModule.Domain.Entities
{
    public class Recipe
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ReceipeId { get; set; }
        
        public string ProductName { get; set; }
        public string Comments { get; set; }
        public int ProjectId { get; set; }
        public Projects Project { get; set; }

        public DateTime CreatedDate { get; set; }
        public int AdditiveId { get; set; }
        public Additive Additives { get; set; }
        public int MainPolymerId { get; set; }
        public MainPolymer MainPolymer { get; set; }

    }
}
