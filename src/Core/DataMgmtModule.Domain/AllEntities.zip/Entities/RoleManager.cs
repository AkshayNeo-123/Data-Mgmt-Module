﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMgmtModule.Domain.Entities
{
    public class Roles
    {
        [Key]
        public int RoleId {  get; set; }
        [Required]
        public string RoleName { get; set; }
        = string.Empty;
        [Required]
        public string Description {  get; set; }
    }
}
