﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataMgmtModule.Domain.Entities
{
    public class RecipeComponent
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RecipeComponentId { get; set; }
        public int RecipeId { get; set; }
        public Recipe Recipe { get; set; }
        public decimal WtPercent { get; set; }
        public decimal ValPercent { get; set; }
        public decimal Density { get; set; }
        public bool MP { get; set; }
        public bool MF { get; set; }
        public int ComponentId { get; set; }
        public Component Component { get; set; }

    }
}
