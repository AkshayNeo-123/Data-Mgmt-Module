﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataMgmtModule.Domain.Entities
{
    public class Additive
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }
        public string Additive_Name { get; set; }
        public ICollection<Recipe> Recipes { get; set; }
    }
}